<!doctype html>
<html lang="en">
 <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--favicon-->
        <link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon-32x32.png" type="image/png" />
        <!--plugins-->
        <link href="<?php echo base_url(); ?>assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
        <!-- loader-->
        <link href="<?php echo base_url(); ?>assets/css/pace.min.css" rel="stylesheet" />
        <script src="<?php echo base_url(); ?>assets/js/pace.min.js"></script>
        <!-- Bootstrap CSS -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/icons.css" rel="stylesheet">
        <!-- Theme Style CSS -->
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/dark-theme.css" />
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/semi-dark.css" />
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/header-colors.css" />
        <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
		
        <title>Machine Test</title>

        <link rel="manifest" href="<?php echo base_url();?>manifest.json">
	<style type="text/css">
		.add-to {
			background-color: #E02D44; 
			width: 30%;
		} 
		.add-to-btn {
			background-color: #E02D44; 
			color: white; 
			border: none; 
			outline:none; 
			font-weight: bold; 
			width: 100%; 
			height: 50px; 
		} 
	</style>

<script type="text/javascript" language="javascript">
       $(function() {
            $(this).bind("contextmenu", function(e) {
                e.preventDefault();
            });
        }); 
        document.onkeydown = function(e) {
  if(event.keyCode == 123) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
     return false;
  }
}
</script>

    </head>


    <body class="bg-theme bg-theme1">
        <!--wrapper-->
        <div class="wrapper">
            <!--sidebar wrapper -->
            <div class="sidebar-wrapper" data-simplebar="true">
                <div class="sidebar-header">
              
                    <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
                    </div>
                </div>
                <!--navigation-->
                <ul class="metismenu" id="menu">


                    <li>
                        <a href="<?php echo base_url('index.php/admin/addtask'); ?>">
                            <div class="parent-icon"><i class="bx bx-home-circle"></i>
                            </div>
                            <div class="menu-title">Add Task</div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('index.php/admin/viewtask'); ?>">
                            <div class="parent-icon"><i class="bx bx-home-circle"></i>
                            </div>
                            <div class="menu-title">View Task</div>
                        </a>
                    </li>
                    
                    
                    <li>
                        <a href="<?php echo base_url('index.php/admin/login'); ?>">
                            <div class="parent-icon"><i class="bx bx-lock"></i>
                            </div>
                            <div class="menu-title">Logout</div>
                        </a>
                    </li>
                    
                </ul>
                <!--end navigation-->
            </div>
            <!--end sidebar wrapper -->
            <!--start header -->
            <header>
                <div class="topbar d-flex align-items-center">
                    <nav class="navbar navbar-expand">
                        <div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
                        </div>
                       
                        <div class="top-menu ms-auto">
                           
                                
                                
                                                           </ul>
                        </div>
                        
                        
                        
                        
                   
                        
                        
                        
                        
                        
                        
                </div>
            </header>
<body>
<br /><br /><br /><br /><br /><br /><br />
<div class="card" style="padding-left:300px">
<div class="card-body">
<form class="form-horizontal" enctype="multipart/form-data" action="<?php echo base_url('index.php/admin/inserttask'); ?>" id="formsub" name="formsub" method="POST">

<div class="form-group">
<label for="input-Default" class="col-sm-2 control-label">Task</label>
<div class="col-sm-6">
<input type="text" id="tasks" class="form-control" name="tasks"  /></div>
</div>
<div class="form-group">
<label for="input-Default" class="col-sm-2 control-label">Task Date </label>
<div class="col-sm-6">
<input type="date" id="dates" name="dates" class="form-control"/>
</div>
</div>


<div class="form-group">
<label for="input-Default" class="col-sm-2 control-label">Start Time</label>
<div class="col-sm-6">
<input type="time" name="starttime"  class="form-control" required="required" id="start"/>
</div></div>
<div class="form-group">
<label for="input-Default" class="col-sm-2 control-label">End Time</label>
<div class="col-sm-6">
<input type="time" name="endtime" class="form-control"  required="required" id="endtime"/>

</div>


</div>

</div>
<div class="form-group">
<div class="col-sm-6">
<button type="submit"  class="btn btn-primary px-5"><i class="bx bx-task mr-1"></i>ADD TASK</button>

</div>


</div>

</div>


</div>

</div>







</form> 
</div>
</div>










</div><!-- Row -->
</div><!-- Main Wrapper -->
<script type="text/javascript">
$(function () {
var today = new Date().toISOString().split('T')[0];
document.getElementsByName("dates")[0].setAttribute('min', today);
});
$(document).ready(function () {
$("#rests").select2();

});



</script>


<script type="text/javascript">

$('#user').on('change', function () {
var mtype = $(this).val();
$.ajax({
type: 'POST',
url: '<?php echo base_url(); ?>index.php/admin/staffbydep',
data: {data: mtype},
dataType: "html",
success: function (val) {

document.getElementById("cats").innerHTML = val;

}
});
});

$('textarea').keyup(function (e) {
var rows = $(this).val().split("\n");
$(this).prop('rows', rows.length);
});

</script>

</body>