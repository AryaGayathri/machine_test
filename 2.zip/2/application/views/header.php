<!doctype html>
<html lang="en">
 <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--favicon-->
        <link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon-32x32.png" type="image/png" />
        <!--plugins-->
        <link href="<?php echo base_url(); ?>assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
        <!-- loader-->
        <link href="<?php echo base_url(); ?>assets/css/pace.min.css" rel="stylesheet" />
        <script src="<?php echo base_url(); ?>assets/js/pace.min.js"></script>
        <!-- Bootstrap CSS -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/icons.css" rel="stylesheet">
        <!-- Theme Style CSS -->
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/dark-theme.css" />
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/semi-dark.css" />
        <link rel="<?php echo base_url(); ?>stylesheet" href="assets/css/header-colors.css" />
        <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
		
        <title>Machine Test</title>

        <link rel="manifest" href="<?php echo base_url();?>manifest.json">
	<style type="text/css">
		.add-to {
			background-color: #E02D44; 
			width: 30%;
		} 
		.add-to-btn {
			background-color: #E02D44; 
			color: white; 
			border: none; 
			outline:none; 
			font-weight: bold; 
			width: 100%; 
			height: 50px; 
		} 
	</style>

<script type="text/javascript" language="javascript">
       $(function() {
            $(this).bind("contextmenu", function(e) {
                e.preventDefault();
            });
        }); 
        document.onkeydown = function(e) {
  if(event.keyCode == 123) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
     return false;
  }
}
</script>

    </head>


    <body class="bg-theme bg-theme1">
        <!--wrapper-->
        <div class="wrapper">
            <!--sidebar wrapper -->
            <div class="sidebar-wrapper" data-simplebar="true">
                <div class="sidebar-header">
              
                    <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
                    </div>
                </div>
                <!--navigation-->
                <ul class="metismenu" id="menu">


                    <li>
                        <a href="<?php echo base_url('index.php/admin/addtask'); ?>">
                            <div class="parent-icon"><i class="bx bx-home-circle"></i>
                            </div>
                            <div class="menu-title">Back</div>
                        </a>
                    </li>
                    
                    
                    
                    
                </ul>
                <!--end navigation-->
            </div>
            <!--end sidebar wrapper -->
            <!--start header -->
            <header>
                <div class="topbar d-flex align-items-center">
                    <nav class="navbar navbar-expand">
                        <div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
                        </div>
                       
                        <div class="top-menu ms-auto">
                           
                                
                                
                                                           </ul>
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                </div>
            </header>
