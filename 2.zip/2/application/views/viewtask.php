<?php
foreach ($data as $dat){
    echo $dat->task_name;


}
?>