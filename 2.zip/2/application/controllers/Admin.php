<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

public function __construct() {
parent::__construct();
error_reporting(E_ALL & ~E_NOTICE);
$this->load->helper(array('form', 'url'));
$this->load->model('admin_m');
$this->load->library('session');
$this->load->helper('cookie');
$this->load->library('upload');
}
//arya starts edit


function login() {

    $this->load->view('login.php');
    }

    function addtask() {
      
       // $this->load->view('header.php');
        
    $this->load->view('addtask.php');
    }
   
function inserttask() {
   $sess = $this->session->userdata('users');
    
     $logid = $this->session->userdata('logdata');
     $sessdate = date('Y-m-d H:i:s');
    $sessurl = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $logca = array('u_id' => $logid, 'track_url' => $sessurl, 'track_datetime' => $sessdate);
  $this->admin_m->inserttrack($logca);
   
    $tasks = $this->input->post('tasks');
    $deid = $this->input->post('user');
    $user = $this->input->post('staff');
    $id = $this->input->post('id');
    $ttype = $this->input->post('tasktype');
    $rests = $this->input->post('rests');
    if ($this->input->post('dates')) {
    $fdate = $this->input->post('dates');
    $fdate = date("Y-m-d", strtotime($fdate));
    $start_time =$this->input->post('starttime');
    $end_time=$this->input->post('endtime');
    
    } else {
    $fdate = "";
    }
    date_default_timezone_set("Europe/london");
    $dates = date("Y-m-d H:i:s");
    
    $arr = array('task_name' =>$tasks, 'task_date'=>$fdate, 'start_time'=>$start_time, 'end_time'=>$end_time, 'status'=>'Pending', 'completed_on'=>'', 'completed_by'=>'' );
    
    
    if ($this->admin_m->inserttask($arr)) {
    redirect('admin/addtask');
    } else {
    redirect('admin/addtask');
    }
    
    }
      
    
function checklogin() {

    $username = $this->input->post('username');
    $password = $this->input->post('password');
    if($username='sraff@staff' &&  $password='staff'){

        $ips = $_SERVER['REMOTE_ADDR'];
        //date_default_timezone_set("Europe/london");
        $dates = date("d-m-Y h:i:s a");
        $arrs = array('userid' => $sess, 'ipaddr' => $ips, 'login' => $dates);
      
        
        
        redirect('admin/addtask');
    
    
       }
    $logs = array('username' => $username, 'password' => $password);
    $dats = $this->admin_m->checklogin($logs);
    if ($dats != "") {
    if ($this->input->post("chkremember")) {
    
    $this->input->set_cookie('uemail', $username, 86500); /* Create cookie for store emailid */
    $this->input->set_cookie('upassword', $password, 86500);
    } else {
    delete_cookie('uemail'); /* Delete email cookie */
    delete_cookie('upassword');
    }
    
    foreach ($dats as $value) {
    $id = $value->id;
    }
    $this->session->set_userdata('users', $id);
    $sess = $this->session->userdata('users');
    
    
    if ($sess != "") {
    $ips = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set("Europe/london");
    $dates = date("d-m-Y h:i:s a");
    $arrs = array('userid' => $sess, 'ipaddr' => $ips, 'login' => $dates);
    $logid = $this->admin_m->insertlog($arrs);
    $this->session->set_userdata('logdata', $logid);
    
    
    redirect('admin/addtask');
    }
    } else {
    
    $this->session->set_flashdata('error', 'Incorrect username or password');
    redirect('admin/login', 'error');
    }
    
    /* } else {
    
    $this->session->set_flashdata('error','Incorrect username');
    redirect('admin/login','error');
    } */
    }
    function viewtask() {
    
        $sess = $this->session->userdata('users');

        $this->load->view('header.php');
        if ($sess != "") {
        $data = $this->admin_m->getdayorders();
?>
<br /><br /><br /><br /><br /><br /><br />
<table border ="2px" class="table table-responsive">
    <tr>
<th>Task Id</th>
<th>Task Name</th>
<th>Task Date</th>
<th> Starts</th>
<th>Ends</th>
<th>Status</th>
<th></th>
        </tr>
<?php


        foreach ($data as $keys) {
            ?>
  <tr>
<th><?php  echo $keys->id;  ?></th>
<th><?php  echo $keys->task_name;  ?></th>
<th><?php  echo $keys->task_date;  ?></th>
<th> <?php  echo $keys->start_time;  ?></th>
<th><?php  echo $keys->end_time;  ?></th>
<th><?php  echo $keys->status;  ?></th>
<th><?php  echo $keys->completed_on;  ?></th>
<th></th>
<!--<th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdateaccept/' . $keys->id); ?>" >Accept</a></th>
<th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdatereject/' . $keys->id); ?>" >Reject</a></th>

<th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdate/' . $keys->id); ?>" >Mark as Complete</a></th>
        -->  </tr>
            <?php
   
        }


        ?></table><?php
        }else{
            $data = $this->admin_m->getdayorders();
            ?>
            <br /><br /><br /><br /><br /><br /><br />
            <table border ="2px" class="table table-responsive">
                <tr>
            <th>Task Id</th>
            <th>Task Name</th>
            <th>Task Date</th>
            <th> Starts</th>
            <th>Ends</th>
            <th>Status</th>
            <th></th>
                    </tr>
            <?php
            
            
                    foreach ($data as $keys) {
                        ?>
              <tr>
            <th><?php  echo $keys->id;  ?></th>
            <th><?php  echo $keys->task_name;  ?></th>
            <th><?php  echo $keys->task_date;  ?></th>
            <th> <?php  echo $keys->start_time;  ?></th>
            <th><?php  echo $keys->end_time;  ?></th>
            <th><?php  echo $keys->status;  ?></th>
            <th><?php  echo $keys->completed_on;  ?></th>
            <th></th>
           <th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdateaccept/' . $keys->id); ?>" >Accept</a></th>
            <th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdatereject/' . $keys->id); ?>" >Reject</a></th>
            
            <th><a class="btn btn-danger" href="<?php echo base_url('index.php/admin/viewtaskupdate/' . $keys->id); ?>" >Mark as Complete</a></th>
                  </tr>
                        <?php
               
                    }
            
            
                    ?></table><?php
                  

        }

    }
    function viewtaskupdate($id) {
        $dates = date("Y-m-d H:i:s");
$arr = array('status' => "completed", 'completed_on' => $dates);
$ca = array('id' => $id);
if ($this->admin_m->updatetask($arr, $ca)) {
redirect('admin/viewtask');
}
    }
    function viewtaskupdateaccept($id) {
        $dates = date("Y-m-d H:i:s");
$arr = array('status' => "Acepted", 'completed_on' => $dates);
$ca = array('id' => $id);
if ($this->admin_m->updatetask($arr, $ca)) {
redirect('admin/viewtask');
}
    }
    function viewtaskupdatereject($id) {
        $dates = date("Y-m-d H:i:s");
$arr = array('status' => "Rejected", 'completed_on' => $dates);
$ca = array('id' => $id);
if ($this->admin_m->updatetask($arr, $ca)) {
redirect('admin/viewtask');
}
    }

  
    }
//arya end edits
