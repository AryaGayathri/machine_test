<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_m extends CI_Model {

public function __construct(){
	parent::__construct();
	$this->load->database();
}
//arya starts
function getdayorders()
{
    $dat=$this->db->query("SELECT * FROM `task_data` ");
    return $dat->result();
	//date_default_timezone_set("Europe/London");
	//$ordertime = date("Y-m-d");
    //$dat=$this->db->query("SELECT * FROM `task_data`");
	//$dats= $dat->result();
}
function checklogin($logs)
{
    
 $this->db->select('id');
       $this->db->from('login');
       $this->db->where($logs);
       $dat=$this->db->get();
       if($dat->num_rows()>0)
        {
          return $dat->result();
        } else {
        return false;
       }

}
function inserttrack($logca)
{
	$sql=$this->db->insert('stafftracking',$logca);
$result=$this->db->insert_id();
return $result;
}
function viewtaskupdate($id)
{
  $t=date("y-m-d H:s");
    $dat=$this->db->query("UPDATE task_data SET status='Completed' and  completed_on='$t' WHERE id=$id");

}

function updatetask($arr,$ca)
{
	$this->db->where($ca);
	$this->db->update('task_data',$arr);
	if($this->db->affected_rows()>0)
	{
		return true;
	}
}
function updatetaskdel($ca)
{
	$this->db->where($ca);
	$this->db->delete('task_data');
	
}

function getuser($sess)
{
    $dat=$this->db->query("SELECT * FROM `login` where id=$sess");
	return $dat->result();
}
//arya ends
//arya
function inserttask($arr)
{
	$sql=$this->db->insert('task_data',$arr);
$result=$this->db->insert_id();
return $result;
}
//arya
}